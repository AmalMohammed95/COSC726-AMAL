# Lab 2 Decision Memo

## Environment

- Model: `Qwen/Qwen2.5-1.5B-Instruct`
- Transformers: `5.13.1`
- Pydantic: `2.13.4`
- Constrained-decoding backend: `outlines-v1`
- Hardware: Google Colab T4 GPU
- Decoding: greedy generation

## 1. What exactly changed?

From A to B, I replaced the naive one-line instruction with a six-block
system prompt containing identity, scope, checkable constraints, an output
contract derived from Pydantic, tool rules, and invented examples.

From B to C, I retained the system prompt and attached all four available
policies to every request.

From C to D, I changed only the context-selection strategy. Instead of sending
all policies, I used a keyword selector to send only the policies judged
relevant to the current email.

From D to E, I retained the selected-context strategy and used the same system
prompt, but replaced ordinary generation with schema-constrained decoding
through Outlines.

## 2. Which dimensions changed?

The naive prompt achieved only 8% parseability and no schema-valid output.
The structured system prompt increased parseability to 100%, schema validity
to 75%, and field accuracy to 83%.

Sending all evidence reduced schema validity to 67% and coherence to 58%.
Selected evidence improved schema validity to 92%, referential validity to
92%, and coherence to 92%, while reducing runtime from 27.5 to 23.5 seconds.
However, its field accuracy fell from 81% to 73%, showing that the selector
did not improve every dimension.

Constrained decoding achieved 100% parseability, 100% schema validity, 92%
referential validity, 100% coherence, and 75% field accuracy.

## 3. Which technique would I ship, and at what cost?

I would ship Technique E with Pydantic validation, referential checks, policy
gates, monitoring, and human escalation. It provided the strongest structural
guarantees and completed the twelve-case evaluation in 22.8 seconds, or about
1.9 seconds per case in this run.

The notebook did not record generated-token usage or monetary API cost, so a
financial cost per call cannot be claimed. The all-evidence context contained
approximately 97 policy tokens before prompt and email tokens were counted.

## 4. Which failure remains?

Constrained decoding does not guarantee semantic truth. In E01 it produced a
schema-valid but incorrect `days_late` value during inspection. In E09 it
returned `refund` rather than the gold intent `late_delivery`, although it did
not claim that a refund had already been executed.

Referential validity also remained at 92%. A value can match the schema pattern
while referring to no existing order. Gate 3 catches unknown order IDs by
checking them against `KNOWN_ORDER_IDS`. Gate 4 checks cross-field policy
coherence. Neither guarantee can be supplied by JSON Schema alone.

## 5. What would make me revert?

I would reconsider Technique E if constrained decoding caused unacceptable
latency, became incompatible with the deployed model, prevented necessary valid
outputs, or continued to reduce semantic accuracy on a larger representative
evaluation. I would also revise or replace the evidence selector if case-level
analysis showed that it systematically removed necessary context.

## 6. What did the measurement not tell me?

The evaluation contains only twelve hand-written fixtures created by one
author. It is a smoke test, not a production evaluation. There is no
inter-annotator agreement, independent gold-label review, repeated-run variance
estimate, or confidence interval.

The 1.5B model has a different failure profile from larger frontier models.
Greedy decoding improves comparability within this session but is not a full
reproducibility plan. Only one model snapshot, one hardware environment, and
one prompt family were tested.

The experiment did not measure broad multilingual performance, distribution
shift, long conversations, policy changes, retrieval failures, tool failures,
privacy, fairness, customer satisfaction, or diverse adversarial attacks.
The single injection fixture cannot establish prompt-injection robustness.
A larger independently annotated test set, repeated trials, case-level error
analysis, and production monitoring would be required before deployment.
