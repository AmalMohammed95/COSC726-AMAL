from enum import Enum
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_validator,
    model_validator,
)

KNOWN_ORDER_IDS = {
    "A1032", "A1044", "A1051", "A1067",
    "A1078", "A1080", "A1091", "A1099"
}

POLICY_THRESHOLD_DAYS = 3


class Intent(str, Enum):
    late_delivery = "late_delivery"
    refund = "refund"
    address_change = "address_change"
    cancel_and_refund = "cancel_and_refund"
    other = "other"


class Action(str, Enum):
    check_status = "check_status"
    request_approval = "request_approval"
    escalate_to_human = "escalate_to_human"
    reply_only = "reply_only"


class TriageResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    intent: Intent = Field(
        description="The supported intent that best classifies the email."
    )

    order_id: str | None = Field(
        default=None,
        pattern=r"^A[0-9]{4}$",
        description=(
            "The supported order ID matching A followed by four digits; "
            "otherwise null."
        ),
    )

    days_late: int | None = Field(
        default=None,
        ge=0,
        le=365,
        description=(
            "The supported number of late days from 0 to 365; "
            "otherwise null."
        ),
    )

    proposed_action: Action = Field(
        description="The permitted next support action."
    )

    evidence_ids: list[str] = Field(
        default_factory=list,
        description="IDs of evidence supporting the result.",
    )


class ValidatedTriage(TriageResult):

    @field_validator("order_id")
    @classmethod
    def validate_order_exists(cls, value):
        if value is not None and value not in KNOWN_ORDER_IDS:
            raise ValueError(
                f"well-formed but unknown order_id: {value}"
            )
        return value

    @model_validator(mode="after")
    def validate_policy_coherence(self):
        if (
            self.intent == Intent.late_delivery
            and self.order_id is None
        ):
            raise ValueError(
                "late_delivery without an order_id is incoherent"
            )

        if (
            self.intent == Intent.late_delivery
            and self.proposed_action == Action.request_approval
            and (
                self.days_late is None
                or self.days_late < POLICY_THRESHOLD_DAYS
            )
        ):
            raise ValueError(
                "approval proposed without at least 3 days late"
            )

        return self
