# Lab 2 Decision Memo

## 1. What changed between the runs?

- A to B: I replaced the one-sentence naive instruction with a structured
  system prompt containing identity, task scope, checkable constraints, and
  an explicit JSON output contract.
- B to C: I kept the system prompt unchanged and added three invented few-shot
  examples. The examples covered an unstated delay value, a compound request
  without an order ID, and an out-of-scope request.
- B to D: I kept the system prompt unchanged and added named intermediate
  reasoning fields and explicit threshold arithmetic for the late-delivery
  policy.
- B to E: I kept exactly the same prompt words and passed the JSON Schema to
  the decoder. Therefore, the decoder was the only changed variable.

## 2. Which dimensions changed?

Technique A achieved only 17% parseability and 17% schema validity. Its 100%
field accuracy is misleading because it was calculated only over the small
number of outputs that parsed.

Technique B increased parseability to 100%, schema validity to 67%, and field
accuracy to 85%, but it still failed the safety gate.

Technique C achieved 100% parseability, 92% schema validity, 92% field
accuracy, an 8% false-fill rate, and passed the safety gate.

Technique D achieved 100% parseability, 100% schema validity, 96% field
accuracy, an 8% false-fill rate, and passed the safety gate.

Technique E matched D's quality and safety results: 100% parseability, 100%
schema validity, 96% field accuracy, and an 8% false-fill rate.

## 3. Which technique would I ship, and at what cost?

I would ship Technique E, schema-constrained decoding. It matched the best
measured quality while using approximately 357 tokens per call with a median
latency of 540 ms. Technique D produced the same quality but required about
462 tokens per call and 1850 ms median latency. Because the lab uses a
deterministic simulator, these are simulated resource costs rather than real
API prices.

## 4. Which failure remains, and which gate catches it?

E11 remains a failure under every technique. The malformed order number `1102`
is changed into `A1102`, which matches the schema pattern but does not refer to
a real order. Gate 2 cannot detect this because the value is structurally
valid. Gate 3 catches it by checking the value against the known order IDs.

The E99 adversarial test also produced an unsupported evidence reference:
`MSG-E01` instead of `MSG-E99`. Gate 3 correctly rejected it. The prompt
resisted the embedded instruction, but validation was still necessary.

## 5. What would make me revert this choice?

I would revert or reconsider Technique E if the constrained-decoding backend
became incompatible with the selected model, introduced unacceptable latency,
prevented required valid responses, or produced lower semantic accuracy on a
larger representative evaluation set. I would also reconsider it if the
deployment platform did not support schema-constrained generation reliably.

## 6. What did the measurement not tell me?

The evaluation used only twelve hand-written fixtures created by one author,
so it is a smoke test rather than a representative production evaluation.
There was no inter-annotator agreement study and no independent review of the
gold labels. A single Arabic case cannot establish multilingual robustness.

The experiment used a deterministic simulator with a published fault model
instead of a real language model. Therefore, its failure distribution, token
counts, and latency do not establish real-world performance or API cost.
Temperature zero removes sampling variance in this simulator but is not a
complete reproducibility plan for real systems.

The experiment also did not measure performance under distribution shift,
long conversations, diverse prompt-injection attacks, changing policies,
concurrent requests, tool failures, retrieval errors, or malicious evidence.
It did not measure customer satisfaction, fairness, privacy, operational
reliability, or the quality of human escalation. A larger independently
annotated test set and real-model trials would be required before deployment.
